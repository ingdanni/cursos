package com.example.retrofitejemplo

// Agregar Adapter