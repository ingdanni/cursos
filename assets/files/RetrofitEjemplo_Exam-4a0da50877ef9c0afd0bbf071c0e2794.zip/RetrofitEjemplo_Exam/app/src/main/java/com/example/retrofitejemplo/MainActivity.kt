package com.example.retrofitejemplo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onResume() {
        super.onResume()

        Api.retrofitService.getUsers().enqueue(
            object: Callback<List<User>> {

                override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                    // Agregar configuracion de recycler view

                    Log.i("Retrofit response body", response.body().toString())
                }

                override fun onFailure(call: Call<List<User>>, t: Throwable) {
                    Log.i("Retrofit", t.message.toString())
                }
            }
        )
    }
}