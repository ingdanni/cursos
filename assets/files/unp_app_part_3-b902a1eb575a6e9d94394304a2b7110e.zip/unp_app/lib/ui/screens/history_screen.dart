import 'package:flutter/material.dart';
import 'package:unp_app/models/course_response.dart';
import 'package:unp_app/services/courses_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {

  late Future<List<CourseResponse>> history;

  @override
  void initState() {
    super.initState();

    history = CoursesService.getHistory();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<CourseResponse>>(
        future: history,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return buildListOfTeachers(snapshot.data!);
          }

          return Center(child: CircularProgressIndicator(),);
        });
  }

  Widget buildListOfTeachers(List<CourseResponse> courses) {
  
    return ListView.builder(
        itemCount: courses.length,
        itemBuilder: (context, index) {
      return Card(
        elevation: 4,
        child: ListTile(
          title: Text(courses[index].name),
          subtitle: Padding(
            padding: EdgeInsets.only(top: 4, bottom: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Maestro: " + courses[index].teacher),
                Text("Nota final: " + courses[index].note.toString()),
              ],
            ),
          ),
        ),
      );
    });
  }
}
