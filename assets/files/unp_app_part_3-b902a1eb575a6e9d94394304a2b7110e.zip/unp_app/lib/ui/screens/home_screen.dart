import 'package:flutter/material.dart';
import 'package:unp_app/services/courses_service.dart';
import '../../models/course_response.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  late Future<List<CourseResponse>> cursos;

  @override
  void initState() {
    super.initState();

    cursos = CoursesService.getCourses();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<CourseResponse>>(
        future: cursos,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
              return buildListOfCourses(snapshot.data!);
          }

          return const Center(child: CircularProgressIndicator(),);
      });
  }

  Widget buildListOfCourses(List<CourseResponse> courses) {
    return ListView.builder(
      itemCount: courses.length,
        itemBuilder: (context, index) {
          return Padding(
              padding: const EdgeInsets.all(4),
          child: Card(
            elevation: 4,
            child: ListTile(
              title: Text(courses[index].name),
              subtitle: Text(courses[index].teacher),
              trailing: CircleAvatar(
                child: Text(courses[index].note.toString()),
              ),
            ),
          ),);
        });
  }
}
