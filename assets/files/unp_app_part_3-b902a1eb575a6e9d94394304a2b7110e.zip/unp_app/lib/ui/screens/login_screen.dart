import 'package:flutter/material.dart';
import '../../ui/screens/main_navigation_screen.dart';
import '../../models/login_response.dart';
import '../../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final _formKey = GlobalKey<FormState>();
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  Future<LoginResponse>? _response;

  Widget? _child;

  @override
  void initState() {
    super.initState();

    _child = buildLoginFormUI();

    AuthService.getToken()
      .then((value) {
        if (value != null) {
          setState(() {
            _child = const MainNavigationScreen();
          });
        }
      });
  }

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: (_response != null)  ?  buildMainView()  :  _child,
    );
  }

  Widget buildLoginFormUI([String? errorMessage]) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          children: [

            const SizedBox(height: 32),

            const Text("UNP", style: TextStyle(fontSize: 32),),

            const Text("Universidad Nacional Portuguesa", style: TextStyle(fontSize: 16),),

            const SizedBox(height: 32),

            // Email field
            TextFormField(
              controller: usernameController,
              decoration: const InputDecoration(
                  icon: Icon(Icons.person),
                  border: OutlineInputBorder(),
                  hintText: 'Ingrese su usuario'
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Ingrese su usuario';
                }

                return null;
              },
            ),

            // Separator
            const SizedBox(height: 16),

            // Password field
            TextFormField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                  icon: Icon(Icons.key),
                  border: OutlineInputBorder(),
                  hintText: 'Ingrese su contraseña'
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Ingrese su contraseña';
                }

                if (value.length <= 6) {
                  return 'La contraseña debe contener más de 6 caracteres';
                }

                return null;
              },
            ),

            // Separator
            const SizedBox(height: 16),

            // Error message
            (errorMessage != null) ? Text(errorMessage) : const SizedBox(),

            // Separator
            const SizedBox(height: 16),

            // Submit button
            SizedBox(
              width: double.infinity,
              height: 44,
              child: ElevatedButton(
                  onPressed: () {

                    if (_formKey.currentState!.validate()) {
                      setState(() {
                        _response = AuthService.login(usernameController.text, passwordController.text);
                      });
                    }
                  },
                  child: const Text("Iniciar sesión")
              ),
            )
          ],
        ),
      ),
    );
  }

  FutureBuilder<LoginResponse> buildMainView() {
    return FutureBuilder<LoginResponse>(
        future: _response,
        builder: (context, snapshot) {

          if (snapshot.hasData) {
            return const MainNavigationScreen();
          }

          if (snapshot.hasError) {
            return buildLoginFormUI(snapshot.error.toString());
          }

          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

}
