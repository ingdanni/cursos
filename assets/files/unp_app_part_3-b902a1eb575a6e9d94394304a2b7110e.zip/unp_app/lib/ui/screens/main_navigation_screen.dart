import 'package:flutter/material.dart';
import 'package:unp_app/services/auth_service.dart';
import 'package:unp_app/ui/screens/history_screen.dart';
import 'package:unp_app/ui/screens/home_screen.dart';
import 'package:unp_app/ui/screens/teachers_screen.dart';
import '../../models/user_response.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({Key? key}) : super(key: key);

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {

  String _title = "Mis cursos";
  Widget _child = HomeScreen();

  late Future<UserResponse> usuario;

  @override
  void initState() {
    super.initState();

    usuario = AuthService.getUser();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<UserResponse>(
      future: usuario,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return buildContent(snapshot.data!);
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        });
  }

  Widget buildContent(UserResponse usuario) {
    return Scaffold(
      appBar: AppBar(title: Text(_title),),
      body: _child,
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Colors.red,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 60,
                    width: 60,
                    child: CircleAvatar(
                      backgroundImage: NetworkImage(usuario.picture),
                    ),
                  ),
                  const SizedBox(height: 16,),
                  Text("${usuario.name} ${usuario.lastname}", style: TextStyle(color: Colors.white),),
                  const SizedBox(height: 4,),
                  Text(usuario.email, style: TextStyle(color: Colors.white, fontSize: 12),),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.book),
              title: const Text('Mis cursos'),
              onTap: () {
                setState(() {
                  _title = "Mis cursos";
                  _child = HomeScreen();
                });

                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.list),
              title: const Text('Historial'),
              onTap: () {
                setState(() {
                  _title = "Historial";
                  _child = HistoryScreen();
                });

                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.people),
              title: const Text('Maestros'),
              onTap: () {
                setState(() {
                  _title = "Maestros";
                  _child = TeachersScreen();
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Cerrar sesión'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

}
