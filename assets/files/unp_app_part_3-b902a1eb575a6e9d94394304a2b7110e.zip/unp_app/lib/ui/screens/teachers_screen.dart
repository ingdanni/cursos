import 'package:flutter/material.dart';
import 'package:unp_app/services/teachers_service.dart';

import '../../models/teacher_response.dart';

class TeachersScreen extends StatefulWidget {
  const TeachersScreen({Key? key}) : super(key: key);

  @override
  State<TeachersScreen> createState() => _TeachersScreenState();
}

class _TeachersScreenState extends State<TeachersScreen> {

  late Future<List<TeacherResponse>> teachers;

  @override
  void initState() {
    super.initState();

    teachers = TeachersService.getTeachers();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<TeacherResponse>>(
        future: teachers,
        builder: (context, snapshot) {

      if (snapshot.hasData) {
        return buildListOfTeachers(snapshot.data!);
      }

      return Center(child: CircularProgressIndicator(),);
    });
  }

  Widget buildListOfTeachers(List<TeacherResponse> teachers) {

    return ListView.builder(
      itemCount: teachers.length,
        itemBuilder: (context, index) {
        return Card(
          elevation: 4,
          child: ListTile(
            leading: CircleAvatar(child: Icon(Icons.person),),
            title: Text("${teachers[index].name} ${teachers[index].lastname}"),
            subtitle: Text(teachers[index].email),
          ),
        );
    });
  }
}
