import '../models/course_response.dart';
import '../models/course_detail_response.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CoursesService {

  static const String url = 'https://shrouded-harbor-95996.herokuapp.com';

  static Future<List<CourseResponse>> getCourses() async {
    final response = await http.get(Uri.parse(url + '/courses'));

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final list = json.cast<Map<String, dynamic>>();

      return list.map<CourseResponse>((item) => CourseResponse.fromJson(item)).toList();
    } else {
      throw Exception('Error al obtener lista de cursos');
    }
  }

  static Future<List<CourseDetailResponse>> getCourseById(String id) async {

    final response = await http.get(Uri.parse(url + '/courses/' + id));

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final list = json.cast<Map<String, dynamic>>();

      return list.map<CourseDetailResponse>((item) => CourseDetailResponse.fromJson(item)).toList();
    } else {
      throw Exception('Error al obtener curso');
    }
  }

  static Future<List<CourseResponse>> getHistory() async {

    final response = await http.get(Uri.parse(url + '/courses/history'));

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      final list = json.cast<Map<String, dynamic>>();

      return list.map<CourseResponse>((item) => CourseResponse.fromJson(item)).toList();
    } else {
      throw Exception('Error al obtener el historial de cursos');
    }
  }
}