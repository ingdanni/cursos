import 'package:flutter/material.dart';

// Las enumeraciones, son un tipo especial de clase que se utiliza
// para representar un número fijo de valores constantes.
enum ConversionMode {
  dolarACordoba,
  cordobaADolar,
}

class Convertidor extends StatefulWidget {

  const Convertidor({Key? key, required this.titulo}) : super(key: key);

  final String titulo;

  final double tasaDeCambio = 35.46;

  @override
  State<Convertidor> createState() => _ConvertidorState();
}

class _ConvertidorState extends State<Convertidor> {

  double _resultado = 0.0;

  ConversionMode _conversionMode = ConversionMode.dolarACordoba;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.titulo),
      ),
      body: Container(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[

            TextButton(
                onPressed: () {
                  setState(() {
                    _conversionMode = _conversionMode == ConversionMode.dolarACordoba
                        ? ConversionMode.cordobaADolar
                        : ConversionMode.dolarACordoba;
                  });
                },
                child: Icon(Icons.flip_camera_android)
            ),

            Text(
              _conversionMode == ConversionMode.dolarACordoba
                  ? "Dólar a Córdoba"
                  : "Córdoba a Dólar",
              style: const TextStyle(fontSize: 20),
            ),

            TextField(
              onChanged: (valor) {
                // *** Calcular el valor que se debe mostrar ***
              },
            ),

            Text(
              _resultado.toString(),
              style: Theme.of(context).textTheme.headline2,
            ),
          ],
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
