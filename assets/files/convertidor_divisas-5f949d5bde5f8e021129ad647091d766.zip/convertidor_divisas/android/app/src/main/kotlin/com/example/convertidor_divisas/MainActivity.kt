package com.example.convertidor_divisas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
