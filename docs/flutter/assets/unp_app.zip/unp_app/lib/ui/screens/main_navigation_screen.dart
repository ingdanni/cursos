import 'package:flutter/material.dart';
import 'package:unp_app/ui/screens/history_screen.dart';
import 'package:unp_app/ui/screens/home_screen.dart';
import 'package:unp_app/ui/screens/teachers_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({Key? key}) : super(key: key);

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {

  String _title = "Mis cursos";
  Widget _child = HomeScreen();

  @override
  void initState() {
    super.initState();

  }

  @override
  Widget build(BuildContext context) {
    return buildContent();
  }

  Widget buildContent() {
    return Scaffold(
      appBar: AppBar(title: Text(_title),),
      body: _child,
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Colors.red,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  SizedBox(
                    height: 60,
                    width: 60,
                    child: CircleAvatar(
                      child: Icon(Icons.person),
                    ),
                  ),
                  SizedBox(height: 16,),
                  Text('Alex Hunter', style: TextStyle(color: Colors.white),),
                  Text('ahunter@gmail.com', style: TextStyle(color: Colors.white, fontSize: 12),),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.book),
              title: const Text('Mis cursos'),
              onTap: () {
                setState(() {
                  _title = "Mis cursos";
                  _child = HomeScreen();
                });

                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.list),
              title: const Text('Historial'),
              onTap: () {
                setState(() {
                  _title = "Historial";
                  _child = HistoryScreen();
                });

                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.people),
              title: const Text('Maestros'),
              onTap: () {
                setState(() {
                  _title = "Maestros";
                  _child = TeachersScreen();
                });
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Cerrar sesión'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

}
